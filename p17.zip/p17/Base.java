class Base {
  private void amethod(int iBase) {
    System.out.println("Base.amethod");
  }
}