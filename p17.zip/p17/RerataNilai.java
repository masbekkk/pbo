public class RerataNilai {
  public int average(int a, int b) {
    return (a + b) / 2;
  }

  public double average(double a, double b) {
    return (a + b) / 2;
  }

  public int average(int a, int b, int c) {
    return (a + b + c) / 3;
  }
}
